package modelo;

public class Item {
    private int id;

    private int qtd;

    private String nome;

    private String marca;

    public Item() {
        this.id = -1;
        this.qtd = -1;
        this.nome = "";
        this.marca = "";
    }

    public Item(int id, int qtd, String nome, String marca){
        this.id = id;
        this.qtd = qtd;
        this.nome = nome;
        this.marca = marca;
    }

    public int getId(){
        return this.id;
    }

    public int getQtd(){
        return this.qtd;
    }

    public String getNome(){
        return this.nome;
    }

    public String getMarca(){
        return this.marca;
    }

    public void setId(int valor){
        this.id = valor;
    }

    public void setQtd(int valor){
        this.qtd = valor;
    }

    public void setNome(String palavra){
        this.nome = palavra;
    }

    public void setMarca(String palavra){
        this.marca = palavra;
    }

    public String paraString(){
        return "Item: "+nome+" id: "+id+" quantidade: "+qtd+" local de compra: "+marca;
    }
}

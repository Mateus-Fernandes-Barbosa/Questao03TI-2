package aplicacao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Scanner;
import dao.DAO;
import dao.ItemDAO;
import modelo.Item;
public class Aplicacao {
    public  static BufferedReader BfR = new BufferedReader(new InputStreamReader(System.in));
    public static Scanner leia = new Scanner(System.in);

    public static int Menu() throws IOException {
        int opcao;
        System.out.println("[0] Sair\n[1] Inserir\n[2] Ler\n[3] Atualizar\n[4] Deletar\n[5] Ordenar por Marca\n[6] Ordenar por Id");
        opcao = leia.nextInt();
        return opcao;
    }
    public static void OrdenarId(){
        ItemDAO itemDAO = new ItemDAO();
        List<Item> itens = itemDAO.getOrderById();
        for(Item i : itens){
            System.out.println("Id: " + i.getId());
            System.out.println("Nome: "+i.getNome());
            System.out.println("Marca: "+i.getMarca());
            System.out.println("Quantidade: "+i.getQtd());
        }
    }
    public static void OrdenarMarca(){
        ItemDAO itemDAO = new ItemDAO();
        List<Item> itens = itemDAO.getOrderByMarca();
        for(Item i : itens){
            System.out.println("Id: " + i.getId());
            System.out.println("Nome: "+i.getNome());
            System.out.println("Marca: "+i.getMarca());
            System.out.println("Quantidade: "+i.getQtd());
        }
    }
    public static void Deletar(){
        System.out.println("Escreva o id do item que deseja deletar");
        int id = LeInteiro();
        boolean idValido = VerificaId(id);
        while (!idValido){
            System.out.println("ERROR -- Id não encontrado no banco de dados");
            id = LeInteiro();
            idValido = VerificaId(id);
        }
        ItemDAO itemDAO = new ItemDAO();
        itemDAO.delete(id);
    }
    public static Item LeItem(){
        System.out.print("Escreva a quantidade: ");
        int qtd = LeInteiro();
        System.out.print("\nEscreva o nome: ");
        String nome = LeiaPalavra();
        System.out.print("\nEscreva a marca: ");
        String marca = LeiaPalavra();
        System.out.print("\nEscreva o id: ");
        int id = leia.nextInt();
        Item item = new Item (id, qtd, nome, marca);
        return item;
    }
    public static void Atualizar(){
        int id = LeId(), qtd = 0;
        boolean idValido = VerificaId(id);
        while (!idValido){
            System.out.println("ERROR -- Id não encontrado no banco de dados");
            id = LeId();
            idValido = VerificaId(id);
        }
        ItemDAO itemDAO = new ItemDAO();
        while (qtd <= 0) {
            System.out.print("Escreva a quantidade: ");
            qtd = LeInteiro();
            if(qtd <= 0) {
                System.out.println("ERROR -- Quantidade inválida");
            }
        }
        System.out.print("\nEscreva o nome: ");
        String nome = LeiaPalavra();
        System.out.print("\nEscreva a marca: ");
        String marca = LeiaPalavra();
        Item item = new Item(id, qtd, nome, marca);
        if(itemDAO.update(item)){
            System.out.println("Item atualizado com sucesso");
        }
    }
    public static int LeInteiro(){
        int valor = leia.nextInt();
        return valor;
    }
    public static boolean VerificaId(int id){
        int idItem;
        ItemDAO itemDAO = new ItemDAO();
        boolean idRepetido = false;
        List<Item> itens = itemDAO.getOrderById();
        for(Item i : itens) {
            idItem = i.getId();
            //System.out.println("id: " + id);
            //System.out.println("idItem: " + idItem);
            if (idItem == id) {
                idRepetido = true;
            }
        }
        return idRepetido;
    }
    public static String LeiaPalavra(){
        String palavra = "";
        while(palavra == "") {
            palavra = leia.nextLine();
        }
        return palavra;
    }
    public static void InsereItem(Item item){
        boolean idRepetido = true, qtdInvalida = true;
        ItemDAO itemDAO = new ItemDAO();
        String nome = "", marca = "";
        int id = 0, qtd = 0;
        System.out.print("Nome: ");
        nome = LeiaPalavra();
        System.out.print("\nMarca: ");
        marca = LeiaPalavra();
        while (qtdInvalida) {
            System.out.print("\nQuantidade: ");
            qtd = leia.nextInt();
            if(qtd > 0){
                qtdInvalida = false;
            }
            else{
                System.out.println("ERROR -- Quantidade Invalida");
            }
        }
        while(idRepetido){
            System.out.print("\nId: ");
            id = leia.nextInt();
            idRepetido = VerificaId(id);
            if(idRepetido){
                System.out.println("ERROR -- Id já cadastrado");
            }
        }
        item = new Item(id, qtd, nome, marca);
        if(itemDAO.insert(item) == true){
            System.out.println("Inserção efetuada com sucesso -> " + item.toString());
        }
    }

    public static  int LeId(){
        int id = 0, cont = 0;
        boolean idValido = false;
        while (!idValido && cont < 5) {
            System.out.print("Digite o id que deseja pesquisar: ");
            id = leia.nextInt();
            idValido = VerificaId(id);
            if(!idValido){
                System.out.println("ERROR -- id apresentado não consta no banco de dados");
            }
            cont++;
            if(cont == 5){
                System.out.println("Limite de tentativas atingido");
                id = 0;
            }
        }
        return id;
    }
    public static void ListaItens(){
        ItemDAO itemDAO = new ItemDAO();
        //List<Item> itens = itemDAO.getOrderById();
        Item item;
        int id = 0;
        id = LeId();
        item = itemDAO.get(id);
        System.out.println("Id: "+item.getId());
        System.out.println("Nome: "+item.getNome());
        System.out.println("Quantidade: "+item.getQtd());
        System.out.println("Marca: "+item.getMarca());
    }
    public static void main(String[] args) throws Exception{
        int opcao;

        Item item = new Item();

        do{
            opcao = Menu();
            switch (opcao){
                case 0:
                    System.out.println("Obrigado por utilizar o programa");
                    break;
                case 1:
                    System.out.println("Inserir Item");
                    InsereItem(item);
                    break;
                case 2:
                    System.out.println("Listar itens");
                    ListaItens();
                    break;
                case 3:
                    System.out.println("Atualizar");
                    Atualizar();
                    System.out.println("Item atualizado com sucesso");
                    break;
                case 4:
                    System.out.println("Deletar");
                    Deletar();
                    System.out.println("Deleção feita com sucesso");
                    break;
                case 5:
                    System.out.println("Ordenar itens por marca");
                    OrdenarMarca();
                    break;
                case 6:
                    System.out.println("Ordenar itens por id");
                    OrdenarId();
                    break;
            }
        }while (opcao != 0);

    }

}

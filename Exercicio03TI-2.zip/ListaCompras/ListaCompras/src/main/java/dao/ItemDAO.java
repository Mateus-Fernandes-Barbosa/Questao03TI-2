package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import modelo.Item;
public class ItemDAO extends DAO{

    public ItemDAO(){
        super();
        conectar();
    }

    public void finalize(){
        close();
    }

    public boolean insert(Item item){
        boolean status = false;
        try {
            Statement st = conexao.createStatement();
            String sql = "INSERT INTO listadecompras (idItem, qtdItem, nomeItem, marcaItem) "
                    + "VALUES (" + item.getId() + ", " + item.getQtd() + ", '" + item.getNome() +
                    "', '" + item.getMarca() + "');";
            System.out.println(sql);
            st.executeUpdate(sql);
            st.close();
            status = true;
        } catch (SQLException m){
            throw new RuntimeException(m);
        }
        return status;
    }

    public Item get(int valor){
        Item item = null;
        System.out.println(valor);
        try {
            Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "SELECT * FROM listadecompras WHERE iditem=" + valor;
            System.out.println(sql);
            ResultSet rs = st.executeQuery(sql);
            System.out.println(rs);
            if (rs.next()) {
                item = new Item(rs.getInt("iditem"), rs.getInt("qtditem"), rs.getString("nomeitem"), rs.getString("marcaitem"));

            }
            st.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return item;
    }

    public List<Item> get(){
        return get("");
    }
    public List<Item> getOrderById(){
        return get("idItem");
    }

    public List<Item> getOrderByNome(){
        return get("nomeItem");
    }

    public List<Item> getOrderByMarca(){
        return get("marcaItem");
    }

    private List<Item> get(String orderBy){
        List<Item> itens = new ArrayList<>();
        try{
            Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "SELECT * FROM listadecompras" + ((orderBy.trim().length() == 0) ? "" : (" ORDER BY " + orderBy));
            System.out.println(sql);
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                Item i = new Item(rs.getInt("idItem"), rs.getInt("qtdItem"), rs.getString("nomeItem"), rs.getString("marcaItem"));
                itens.add(i);
            }
        } catch (Exception e){
            System.err.println(e.getMessage());
        }
        return itens;
    }

    public boolean update(Item item){
        boolean status = false;
        try {
            Statement st = conexao.createStatement();
            String sql = "UPDATE listadecompras SET qtditem = "
                    + item.getQtd() + ", nomeitem = '" + item.getNome() + "', marcaitem = '" + item.getMarca()
                    + "'" + " WHERE iditem = " + item.getId();
                    System.out.println(sql);
                    st.executeUpdate(sql);
                    st.close();
                    status = true;
        }catch (SQLException s){
            throw new RuntimeException(s);
        }
        return status;
    }

    public boolean delete(int valor){
        boolean status = false;
        try{
            Statement st = conexao.createStatement();
            String sql = "DELETE FROM listadecompras WHERE iditem = " + valor;
            System.out.println(sql);
            st.executeUpdate(sql);
            st.close();
            status = true;
        } catch (SQLException s){
            throw  new RuntimeException(s);
        }
        return status;
    }
}
